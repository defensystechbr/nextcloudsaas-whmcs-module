<div class="nextcloud-saas-panel">
    <style>
        .nextcloud-saas-panel {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
        }
        .nc-header {
            background: linear-gradient(135deg, #0082c9 0%, #00639a 100%);
            color: #fff;
            padding: 25px 30px;
            border-radius: 10px 10px 0 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .nc-header h2 {
            margin: 0;
            font-size: 22px;
            font-weight: 600;
        }
        .nc-header .nc-logo {
            font-size: 36px;
            opacity: 0.9;
        }
        .nc-status-badge {
            display: inline-block;
            padding: 5px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .nc-status-success {
            background: rgba(255,255,255,0.2);
            color: #a8ffa8;
            border: 1px solid rgba(168,255,168,0.3);
        }
        .nc-status-danger {
            background: rgba(255,255,255,0.2);
            color: #ffa8a8;
            border: 1px solid rgba(255,168,168,0.3);
        }
        .nc-status-warning {
            background: rgba(255,255,255,0.2);
            color: #ffe0a8;
            border: 1px solid rgba(255,224,168,0.3);
        }
        .nc-body {
            background: #f8f9fa;
            border: 1px solid #e0e0e0;
            border-top: none;
            border-radius: 0 0 10px 10px;
            padding: 25px 30px;
        }
        .nc-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }
        .nc-info-card {
            background: #fff;
            border: 1px solid #e8e8e8;
            border-radius: 8px;
            padding: 20px;
            transition: box-shadow 0.2s ease;
        }
        .nc-info-card:hover {
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        .nc-info-card h4 {
            margin: 0 0 12px 0;
            color: #555;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
        }
        .nc-info-card .nc-value {
            font-size: 16px;
            color: #333;
            font-weight: 500;
            word-break: break-all;
        }
        .nc-info-card .nc-value a {
            color: #0082c9;
            text-decoration: none;
        }
        .nc-info-card .nc-value a:hover {
            text-decoration: underline;
        }
        .nc-storage-section {
            background: #fff;
            border: 1px solid #e8e8e8;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 25px;
        }
        .nc-storage-section h3 {
            margin: 0 0 15px 0;
            color: #333;
            font-size: 16px;
            font-weight: 600;
        }
        .nc-progress-bar {
            background: #e9ecef;
            border-radius: 10px;
            height: 24px;
            overflow: hidden;
            margin-bottom: 10px;
        }
        .nc-progress-fill {
            height: 100%;
            border-radius: 10px;
            background: linear-gradient(90deg, #0082c9, #00a2e8);
            transition: width 0.5s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 12px;
            font-weight: 600;
            min-width: 40px;
        }
        .nc-progress-fill.nc-warn {
            background: linear-gradient(90deg, #f0ad4e, #ec971f);
        }
        .nc-progress-fill.nc-danger {
            background: linear-gradient(90deg, #d9534f, #c9302c);
        }
        .nc-storage-details {
            display: flex;
            justify-content: space-between;
            color: #666;
            font-size: 14px;
        }
        .nc-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }
        .nc-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            text-decoration: none;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .nc-btn-primary {
            background: #0082c9;
            color: #fff;
        }
        .nc-btn-primary:hover {
            background: #006ba1;
            color: #fff;
            text-decoration: none;
        }
        .nc-btn-success {
            background: #28a745;
            color: #fff;
        }
        .nc-btn-success:hover {
            background: #218838;
            color: #fff;
            text-decoration: none;
        }
        .nc-btn-info {
            background: #17a2b8;
            color: #fff;
        }
        .nc-btn-info:hover {
            background: #138496;
            color: #fff;
            text-decoration: none;
        }
        .nc-btn-secondary {
            background: #fff;
            color: #333;
            border: 1px solid #ddd;
        }
        .nc-btn-secondary:hover {
            background: #f5f5f5;
            text-decoration: none;
            color: #333;
        }
        .nc-btn-icon {
            font-size: 16px;
        }
        .nc-credentials {
            background: #fff;
            border: 1px solid #e8e8e8;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 25px;
        }
        .nc-credentials h3 {
            margin: 0 0 15px 0;
            color: #333;
            font-size: 16px;
            font-weight: 600;
        }
        .nc-credentials table {
            width: 100%;
        }
        .nc-credentials td {
            padding: 8px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .nc-credentials td:first-child {
            font-weight: 600;
            color: #555;
            width: 180px;
        }
        .nc-credentials td:last-child {
            color: #333;
        }
        .nc-dns-notice {
            background: #e8f4fd;
            border: 1px solid #b8daff;
            border-radius: 8px;
            padding: 15px 20px;
            margin-bottom: 25px;
            color: #004085;
            font-size: 14px;
        }
        .nc-dns-notice strong {
            display: block;
            margin-bottom: 8px;
        }
        .nc-dns-notice code {
            background: rgba(0,0,0,0.05);
            padding: 2px 6px;
            border-radius: 3px;
        }
        .nc-components {
            background: #fff;
            border: 1px solid #e8e8e8;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 25px;
        }
        .nc-components h3 {
            margin: 0 0 15px 0;
            color: #333;
            font-size: 16px;
            font-weight: 600;
        }
        .nc-components-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 10px;
        }
        .nc-component-item {
            padding: 8px 12px;
            background: #f8f9fa;
            border-radius: 6px;
            font-size: 13px;
            color: #555;
        }
        .nc-component-item .nc-comp-icon {
            margin-right: 6px;
        }
        .nc-containers-bar {
            display: inline-block;
            margin-left: 10px;
            font-size: 13px;
            opacity: 0.9;
        }
    </style>

    {* Cabeçalho com estado *}
    <div class="nc-header">
        <div>
            <h2>&#9729; Nextcloud SaaS</h2>
            <span class="nc-status-badge nc-status-{$statusColor}">
                {$instanceStatus}
                {if $containersUp > 0}
                    <span class="nc-containers-bar">
                        ({$containersUp}/{$containersTotal} containers)
                    </span>
                {/if}
            </span>
        </div>
        <div class="nc-logo">&#9729;</div>
    </div>

    <div class="nc-body">
        {* Aviso de DNS com 3 domínios *}
        <div class="nc-dns-notice">
            <strong>&#128204; Registros DNS Necessários (3 domínios)</strong>
            Para o correto funcionamento, os seguintes registros DNS tipo <strong>A</strong> devem apontar para o IP do servidor:
            <br><code>{$domain}</code> &mdash; Nextcloud
            <br><code>{$collaboraDomain}</code> &mdash; Collabora Online (edição de documentos)
            <br><code>{$signalingDomain}</code> &mdash; Signaling HPB (Nextcloud Talk)
        </div>

        {* Grid de Informações *}
        <div class="nc-info-grid">
            <div class="nc-info-card">
                <h4>Nextcloud</h4>
                <div class="nc-value">
                    {if $nextcloudUrl}
                        <a href="{$nextcloudUrl}" target="_blank">{$nextcloudUrl}</a>
                    {else}
                        N/A
                    {/if}
                </div>
            </div>
            <div class="nc-info-card">
                <h4>Collabora Online</h4>
                <div class="nc-value">
                    {if $collaboraUrl}
                        <a href="{$collaboraUrl}" target="_blank">{$collaboraUrl}</a>
                    {else}
                        N/A
                    {/if}
                </div>
            </div>
            <div class="nc-info-card">
                <h4>Signaling (Talk HPB)</h4>
                <div class="nc-value">
                    {if $signalingUrl}
                        <a href="{$signalingUrl}" target="_blank">{$signalingUrl}</a>
                    {else}
                        N/A
                    {/if}
                </div>
            </div>
            <div class="nc-info-card">
                <h4>Utilizador Admin</h4>
                <div class="nc-value">{$username}</div>
            </div>
        </div>

        {* Secção de Armazenamento *}
        <div class="nc-storage-section">
            <h3>&#128190; Armazenamento</h3>
            <div class="nc-progress-bar">
                {assign var="progressClass" value=""}
                {if $storagePercent > 90}
                    {assign var="progressClass" value="nc-danger"}
                {elseif $storagePercent > 70}
                    {assign var="progressClass" value="nc-warn"}
                {/if}
                <div class="nc-progress-fill {$progressClass}" style="width: {if $storagePercent > 0}{$storagePercent}{else}2{/if}%">
                    {if $storagePercent > 10}{$storagePercent}%{/if}
                </div>
            </div>
            <div class="nc-storage-details">
                <span>Usado: <strong>{$storageUsed}</strong></span>
                <span>Quota: <strong>{$storageQuota}</strong></span>
                <span>Utilização: <strong>{$storagePercent}%</strong></span>
            </div>
        </div>

        {* Credenciais *}
        <div class="nc-credentials">
            <h3>&#128272; Credenciais de Acesso</h3>
            <table>
                <tr>
                    <td>URL de Acesso:</td>
                    <td><a href="{$nextcloudUrl}" target="_blank">{$nextcloudUrl}</a></td>
                </tr>
                <tr>
                    <td>Collabora Online:</td>
                    <td><a href="{$collaboraUrl}" target="_blank">{$collaboraUrl}</a></td>
                </tr>
                <tr>
                    <td>Signaling HPB:</td>
                    <td><a href="{$signalingUrl}" target="_blank">{$signalingUrl}</a></td>
                </tr>
                <tr>
                    <td>Utilizador:</td>
                    <td>{$username}</td>
                </tr>
                <tr>
                    <td>Password:</td>
                    <td>
                        <em>Definida na criação do serviço. Use "Alterar Password" para modificar.</em>
                    </td>
                </tr>
            </table>
        </div>

        {* Componentes da instância *}
        <div class="nc-components">
            <h3>&#128230; Componentes da Instância ({$containersTotal} Containers)</h3>
            <div class="nc-components-grid">
                <div class="nc-component-item">
                    <span class="nc-comp-icon">&#9729;</span> Nextcloud (app)
                </div>
                <div class="nc-component-item">
                    <span class="nc-comp-icon">&#128451;</span> MariaDB 10.11 (db)
                </div>
                <div class="nc-component-item">
                    <span class="nc-comp-icon">&#9889;</span> Redis (cache)
                </div>
                <div class="nc-component-item">
                    <span class="nc-comp-icon">&#128339;</span> Cron (agendamento)
                </div>
                <div class="nc-component-item">
                    <span class="nc-comp-icon">&#128196;</span> Collabora Online (office)
                </div>
                <div class="nc-component-item">
                    <span class="nc-comp-icon">&#128222;</span> TURN/STUN (coturn)
                </div>
                <div class="nc-component-item">
                    <span class="nc-comp-icon">&#128268;</span> HaRP (AppAPI)
                </div>
                <div class="nc-component-item">
                    <span class="nc-comp-icon">&#9993;</span> NATS (messaging)
                </div>
                <div class="nc-component-item">
                    <span class="nc-comp-icon">&#127909;</span> Janus Gateway (WebRTC)
                </div>
                <div class="nc-component-item">
                    <span class="nc-comp-icon">&#128225;</span> Spreed Signaling (HPB)
                </div>
            </div>
        </div>

        {* Ações *}
        <div class="nc-actions">
            <a href="{$nextcloudUrl}" target="_blank" class="nc-btn nc-btn-primary">
                <span class="nc-btn-icon">&#9729;</span>
                Aceder ao Nextcloud
            </a>
            <a href="{$collaboraUrl}" target="_blank" class="nc-btn nc-btn-success">
                <span class="nc-btn-icon">&#128196;</span>
                Collabora Office
            </a>
            <a href="{$nextcloudUrl}/apps/spreed" target="_blank" class="nc-btn nc-btn-info">
                <span class="nc-btn-icon">&#128172;</span>
                Nextcloud Talk
            </a>
            <a href="clientarea.php?action=productdetails&id={$serviceid}&modop=custom&a=checkStatus"
               class="nc-btn nc-btn-secondary">
                <span class="nc-btn-icon">&#128260;</span>
                Verificar Estado
            </a>
            <a href="clientarea.php?action=productdetails&id={$serviceid}&modop=custom&a=restartInstance"
               class="nc-btn nc-btn-secondary"
               onclick="return confirm('Tem a certeza que deseja reiniciar a sua instância Nextcloud? Todos os 10 containers serão reiniciados.');">
                <span class="nc-btn-icon">&#128260;</span>
                Reiniciar Instância
            </a>
        </div>
    </div>
</div>
