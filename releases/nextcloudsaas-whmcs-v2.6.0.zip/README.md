# Módulo Nextcloud-SaaS para WHMCS v2.6.0

**Autor:** Defensys / Manus AI  
**Versão:** 2.6.0  
**Licença:** Proprietária

---

## 1. Visão Geral

O Módulo Nextcloud-SaaS para WHMCS é uma solução completa para provisionar e gerir instâncias Nextcloud como um produto de Software as a Service (SaaS). Esta versão foi completamente reescrita para se integrar diretamente com o script `manage.sh` v10.0, que gere uma arquitetura robusta de 10 containers por instância, orquestrada por um proxy reverso Traefik com provisionamento automático de SSL via Let's Encrypt.

Esta integração elimina a necessidade de scripts auxiliares no módulo, centralizando toda a lógica de gestão de instâncias no `manage.sh` do servidor, resultando em maior estabilidade, segurança e facilidade de manutenção.

### 1.1. Arquitetura da Instância

Cada instância provisionada pelo módulo consiste em 10 containers Docker interligados, oferecendo uma solução completa e de alto desempenho:

| Container       | Descrição                                               |
|-----------------|---------------------------------------------------------|
| `app`           | O próprio Nextcloud Hub                                 |
| `db`            | Banco de dados MariaDB 10.11                            |
| `redis`         | Cache de memória para transações e bloqueio de ficheiros|
| `collabora`     | Suite de escritório online Collabora Online             |
| `turn`          | Servidor TURN/STUN para o Nextcloud Talk                |
| `cron`          | Execução de tarefas agendadas em background             |
| `harp`          | HaRP (AppAPI) para integração de aplicações             |
| `nats`          | Sistema de mensagens para o High Performance Backend    |
| `janus`         | Gateway WebRTC para o High Performance Backend          |
| `signaling`     | Servidor de sinalização para o High Performance Backend |

### 1.2. Requisitos de DNS

Para que uma instância funcione corretamente, **três (3) registros DNS do tipo A** devem ser criados e apontados para o endereço IP do servidor de hospedagem:

1.  `dominio.com.br` (para o Nextcloud)
2.  `collabora-dominio.com.br` (para o Collabora Online)
3.  `signaling-dominio.com.br` (para o Nextcloud Talk HPB)

O Traefik irá detetar automaticamente estes domínios e provisionar os certificados SSL correspondentes.

> **Novidade v2.6.0 — Provisionamento Automático:** O cliente já não precisa de configurar os DNS antes da compra. Após o checkout, o sistema verifica automaticamente os registros DNS a cada 5 minutos. Quando todos os 3 registros estiverem corretos, a instância é criada automaticamente e o cliente recebe um email com as credenciais. Se após 3 dias o DNS não estiver configurado, o admin é notificado.

---

## 2. Instalação e Configuração

### 2.1. Pré-requisitos do Servidor

-   Um servidor Ubuntu Linux com o Nextcloud-SaaS (baseado no `manage.sh` v10.0) já instalado em `/opt/nextcloud-customers`.
-   Docker e Docker Compose instalados e a funcionar.
-   Traefik a correr como proxy reverso.
-   Acesso SSH ao servidor a partir do servidor WHMCS.
-   **Utilizador SSH com sudo NOPASSWD:** O utilizador SSH (ex: `defensys`) precisa de permissões de `sudo` sem password. Para configurar, adicione a seguinte linha ao ficheiro `/etc/sudoers` no servidor de hospedagem:
    ```
    defensys ALL=(ALL) NOPASSWD: ALL
    ```

### 2.2. Instalação do Módulo

1.  **Copiar os ficheiros:** Transfira o diretório `nextcloudsaas` para a pasta de módulos do seu WHMCS:
    ```bash
    /caminho/para/whmcs/modules/servers/
    ```

2.  **Verificar a estrutura:** A estrutura final deve ser:
    ```
    /modules/servers/nextcloudsaas/
    ├── hooks.php
    ├── nextcloudsaas.php
    ├── whmcs.json
    ├── lib/
    │   ├── Helper.php
    │   ├── NextcloudAPI.php
    │   └── SSHManager.php
    ├── templates/
    │   ├── clientarea.tpl
    │   └── error.tpl
    └── vendor/  (contém phpseclib3)
    ```

### 2.3. Configuração do Servidor no WHMCS

1.  Vá para **Setup > Products/Services > Servers**.
2.  Crie um novo servidor ou edite um existente.
3.  No campo **Hostname or IP Address**, insira o IP do seu servidor Nextcloud SaaS (ex: `200.50.151.21`).
4.  Em **Server Details**, selecione `Nextcloud SaaS` como o **Module**.
5.  Insira o **Username** (`defensys` ou outro utilizador com acesso sudo) e a **Password** para o acesso SSH.
6.  **Importante:** Desmarque a opção **Secure** (`Check to use SSL Mode for Connections`), pois a comunicação é via SSH, não HTTPS.
7.  **Importante:** Marque a opção **Override with Custom Port** e defina a porta como **22**.
8.  Clique em **Test Connection**. Deverá ver uma mensagem de sucesso.

### 2.4. Configuração do Produto no WHMCS

1.  Vá para **Setup > Products/Services > Products/Services**.
2.  Crie um novo produto.
3.  Na aba **Module Settings**, selecione `Nextcloud SaaS` para o **Module Name** e o servidor que acabou de configurar.
4.  Configure as **Opções do Módulo**:

    | Opção                         | Descrição                                                                                             |
    |-------------------------------|-------------------------------------------------------------------------------------------------------|
    | **Quota de Armazenamento (GB)** | Define a quota de disco para o utilizador `admin` e a quota padrão para todos os novos utilizadores. Ex: `50`. |
    | **Máximo de Utilizadores**      | Define o número máximo de utilizadores que podem ser criados na instância.                            |
    | **Collabora Online**            | Sempre ativo na arquitetura atual. Pode deixar em `on`.                                               |
    | **Nextcloud Talk (HPB)**        | Ativa o High Performance Backend. Deixe em `on`.                                                      |
    | **Caminho da Chave SSH**        | **Opcional.** Se preferir usar autenticação por chave, insira o caminho absoluto para a chave privada no servidor WHMCS. Deixe em branco para usar a password do servidor. |
    | **Prefixo do Nome do Cliente**  | **Opcional.** Adiciona um prefixo ao nome do cliente usado pelo `manage.sh` (ex: `nc-`). Útil para organização. |

5.  Na aba **Custom Fields**, crie os 4 campos abaixo. Os nomes devem ser **exatos**.

**Campo 1: Client Name**
- **Field Name:** `Client Name`
- **Field Type:** Text Box
- **Description:** `Identificador da instância no servidor (preenchido automaticamente)`
- **Validation:** (deixar vazio)
- **Select Options:** (deixar vazio)
- **Display Order:** `1`
- **Admin Only:** Marcado
- **Required Field:** Desmarcado
- **Show on Order Form:** Desmarcado
- **Show on Invoice:** Desmarcado

**Campo 2: Nextcloud URL**
- **Field Name:** `Nextcloud URL`
- **Field Type:** Text Box
- **Description:** `URL de acesso ao Nextcloud`
- **Validation:** (deixar vazio)
- **Select Options:** (deixar vazio)
- **Display Order:** `2`
- **Admin Only:** Desmarcado
- **Required Field:** Desmarcado
- **Show on Order Form:** Desmarcado
- **Show on Invoice:** Desmarcado

**Campo 3: Collabora URL**
- **Field Name:** `Collabora URL`
- **Field Type:** Text Box
- **Description:** `URL do Collabora Online (editor de documentos)`
- **Validation:** (deixar vazio)
- **Select Options:** (deixar vazio)
- **Display Order:** `3`
- **Admin Only:** Desmarcado
- **Required Field:** Desmarcado
- **Show on Order Form:** Desmarcado
- **Show on Invoice:** Desmarcado

**Campo 4: Signaling URL**
- **Field Name:** `Signaling URL`
- **Field Type:** Text Box
- **Description:** `URL do servidor HPB para Nextcloud Talk`
- **Validation:** (deixar vazio)
- **Select Options:** (deixar vazio)
- **Display Order:** `4`
- **Admin Only:** Desmarcado
- **Required Field:** Desmarcado
- **Show on Order Form:** Desmarcado
- **Show on Invoice:** Desmarcado

---

## 3. Funcionalidades do Módulo

### 3.1. Ciclo de Vida do Serviço

-   **CreateAccount:** Verifica primeiro se os 3 registros DNS estão corretos (apontando para o IP do servidor configurado no WHMCS). Se OK, executa `manage.sh <cliente> <dominio> create`. Cria a instância completa, lê o ficheiro `.credentials` gerado, guarda a password do admin no WHMCS, e define a quota padrão para todos os utilizadores. Se DNS não está OK, retorna mensagem informativa e o cron automático continuará verificando.
-   **SuspendAccount:** Executa `manage.sh <cliente> _ stop`. Para todos os 10 containers da instância.
-   **UnsuspendAccount:** Executa `manage.sh <cliente> _ start`. Inicia todos os 10 containers da instância.
-   **TerminateAccount:** Executa `manage.sh <cliente> _ backup` e depois `manage.sh <cliente> _ remove`. Faz um backup completo antes de apagar permanentemente a instância (containers, volumes e dados).
-   **Renew:** Verifica se a instância está ativa e reinicia se necessário.
-   **ChangePackage:** Altera a quota do utilizador `admin` e a quota padrão para novos utilizadores via `occ`.
-   **ChangePassword:** Altera a password do utilizador `admin` via API OCS (método principal) ou `docker exec occ` (fallback SSH).

### 3.2. Botões Personalizados (Admin)

Na área de administração do WHMCS, na página do serviço do cliente, estão disponíveis os seguintes botões:

-   **Verificar Estado:** Mostra o estado de cada um dos 10 containers.
-   **Verificar DNS:** Verifica se os 3 registros DNS (principal, collabora, signaling) apontam para o IP do servidor configurado no WHMCS. Exibe tabela detalhada com status de cada registro.
-   **Reiniciar Instância:** Executa `stop` e `start` (o manage.sh não tem comando restart).
-   **Fazer Backup:** Executa o comando de backup do `manage.sh`.
-   **Atualizar Instância:** Executa o comando de atualização do `manage.sh` (pull + upgrade).
-   **Testar Conexão SSH:** Valida a comunicação com o servidor.
-   **Testar API Nextcloud:** Valida a comunicação com a API OCS da instância.
-   **Ver Credenciais:** Mostra o conteúdo do ficheiro `.credentials` em painel HTML formatado.
-   **Ver Logs:** Mostra as últimas 50 linhas de logs do container `app`.

### 3.3. Botões Personalizados (Cliente)

-   **Verificar Estado:** Mostra o estado dos containers da instância.
-   **Reiniciar Instância:** Reinicia todos os containers.

### 3.4. Área de Cliente

O cliente tem acesso a um painel de controlo completo e moderno, que inclui:

-   **Estado da Instância:** Mostra se a instância está ativa, parada ou parcial, e o número de containers a correr.
-   **Links de Acesso Rápido:** Botões para aceder diretamente ao Nextcloud, Collabora e Talk.
-   **Informações de Armazenamento:** Barra de progresso e detalhes sobre o uso de disco (obtido via `du -sh` no servidor).
-   **Credenciais:** Informações de acesso completas, lidas diretamente do ficheiro `.credentials` da instância.
-   **Componentes da Instância:** Lista dos 10 containers que compõem a sua instância.
-   **Aviso de DNS:** Lembrete constante dos 3 domínios DNS necessários.

---

## 4. Changelog

-   **v2.6.0 (2026-03-27):**
    -   **Novo: Provisionamento automático via verificação DNS por cron.** O sistema verifica automaticamente os registros DNS de serviços pendentes a cada execução do cron WHMCS (recomendado: 5 minutos). Quando os 3 registros DNS estão corretos, a instância é criada automaticamente via `localAPI('ModuleCreate')`.
    -   **Novo: Email automático ao cliente** com credenciais de acesso (URL, usuário, senha) quando a instância é provisionada automaticamente. Email em HTML profissional com todas as informações de serviço.
    -   **Novo: Timeout de 3 dias** para verificação DNS. Se o cliente não configurar os registros em 3 dias, o sistema para de verificar e envia notificação ao administrador com detalhes do serviço e registros DNS necessários.
    -   **Novo: Botão "Verificar DNS" no admin** que mostra tabela detalhada com status de cada registro DNS (hostname, IP esperado, IP resolvido, status OK/FALHA).
    -   **Novo: Funções DNS no Helper.php** — `checkDnsRecords()`, `getRequiredDomains()`, `getServerConfig()` para verificação programática de registros DNS.
    -   **Melhoria: IP do servidor dinâmico** — O IP é sempre obtido do Server configurado no WHMCS (`tblservers`), nunca hardcoded. Funciona corretamente em ambientes multi-servidor.
    -   **Melhoria: Validação DNS no CreateAccount** — Antes de provisionar, verifica se o DNS está correto. Se não estiver, retorna mensagem informativa e o cron continuará verificando.
    -   **Melhoria: ClientArea atualizado** com tabela DNS formatada e mensagem de "Aguardando configuração DNS" para serviços pendentes.
    -   **Melhoria: Hook AfterShoppingCartCheckout** agora grava timestamp de início da verificação DNS nas notas do serviço para controle de timeout.
    -   **Melhoria: Instruções DNS no carrinho** atualizadas com mensagem sobre provisionamento automático.
-   **v2.5.4 (2026-03-27):**
    -   **Correção definitiva do formulário de domínio:** Removida a dependência do formulário SLD/TLD do WHMCS (que rejeitava subdomínios como `next-jaguar.defensys.seg.br`). Agora utiliza um Custom Field "Domínio da Instância" para capturar o hostname completo sem restrições.
    -   **Novo hook `AfterShoppingCartCheckout`:** Copia automaticamente o valor do Custom Field para o campo Domain do serviço, garantindo que `$params['domain']` funciona corretamente em todas as funções do módulo.
    -   **Novo hook `ServiceEdit`:** Sincroniza o campo Domain com o Custom Field quando o serviço é editado no admin.
    -   **JavaScript simplificado:** Mostra instruções DNS junto ao campo de domínio e adiciona validação básica de formato.
    -   **Configuração necessária:** Desativar "Require Domain" no produto e criar Custom Field "Domínio da Instância" (Text Box, obrigatório, Show on Order Form).
-   **v2.5.3 (2026-03-27):**
    -   Corrigida validação de domínio no formulário de order: adicionado `seg.br` e todos os TLDs brasileiros à lista de TLDs compostos
    -   Lista de TLDs compostos expandida para incluir TLDs internacionais comuns (PT, AR, MX, CO, etc.)
    -   Domínios como `next-jaguar.defensys.seg.br` agora são corretamente separados em SLD=`next-jaguar.defensys` e TLD=`seg.br`
-   **v2.5.2 (2026-02-14):**
    -   **Novo:** Atualização automática do ficheiro `.credentials` quando a password é alterada via ChangePassword. A password do Nextcloud no `.credentials` fica sempre sincronizada.
    -   Nova função `updateCredentialsPassword()` no SSHManager com escape correto de caracteres especiais (colchetes, barras, etc.).
-   **v2.5.1 (2026-02-14):**
    -   **Correção crítica:** Username do Nextcloud agora é sempre `admin` (hardcoded). O `$params['username']` do WHMCS pode estar truncado ou diferente (ex: `nextclou`), causando erro "User does not exist" no ChangePassword e outras funções.
    -   Corrigido em: ChangePassword, ChangePackage, ClientArea e AdminServicesTabFields.
-   **v2.5.0 (2026-02-14):**
    -   **Correção:** ChangePassword reestruturado — agora usa API OCS do Nextcloud como método principal (mais rápido e fiável), com fallback para SSH/docker exec occ.
    -   **Correção:** restartInstance no SSHManager corrigido — o manage.sh v10.0 não tem comando `restart`, agora faz `stop` + `start` corretamente.
    -   **Novo:** Quota padrão para todos os utilizadores — ao criar instância ou alterar pacote, a quota é aplicada tanto ao admin como definida como padrão para novos utilizadores via `config:app:set files default_quota`.
    -   **Novo:** Função `setDefaultQuota()` no SSHManager para definir quota padrão via `occ config:app:set`.
    -   **Melhoria:** Logging detalhado no ChangePassword com rastreio de cada etapa (API OCS, fallback SSH).
    -   **Melhoria:** Mensagens de erro mais informativas incluindo output e error do SSH.
-   **v2.4.5 (2026-02-13):**
    -   **Novo:** Hook de personalização da tela de domínio no carrinho — remove o prefixo "www." e o campo de TLD, substituindo por um campo único de domínio completo.
    -   **Novo:** Instruções de DNS exibidas automaticamente na tela de pedido (3 registros A necessários).
    -   **Novo:** Validação automática que remove "www." se o cliente o incluir no domínio.
    -   **Melhoria:** Botões "Ver Credenciais", "Ver Logs" e "Verificar Estado" agora exibem dados em painéis HTML formatados na aba de serviços do admin, em vez de mensagens de erro.
    -   **Correção:** Botão "Ver Credenciais" corrigido — usava método inexistente `credentialsInstance()`, agora usa `getCredentials()`.
    -   **Novo:** Painel de credenciais com layout em grid, organizado por serviço (Nextcloud, Collabora, MariaDB, TURN, Signaling, HaRP, DNS).
    -   **Novo:** Painel de logs com terminal escuro e scroll automático.
    -   **Novo:** Painel de estado com badge colorido (Ativo/Parcial/Parado) e lista detalhada de containers.
-   **v2.3.2 (2026-02-13):**
    -   **Correção:** Botão "Testar API Nextcloud" agora obtém a password real do admin a partir do ficheiro `.credentials` via SSH, corrigindo o erro "Unauthorised".
    -   **Melhoria:** Mensagens de erro mais descritivas no teste de API.
-   **v2.3.1 (2026-02-12):**
    -   **Correção:** Armazenamento na área de cliente agora usa SSH (`du -sh`) em vez da API OCS, alinhando com o painel admin.
-   **v2.3.0 (2026-02-12):**
    -   **Correção:** Utilizador padrão na área de cliente agora é "admin".
    -   **Melhoria:** `parseCredentials()` reescrito para usar `strpos` em vez de regex, corrigindo problemas com UTF-8.
-   **v2.2.0 (2026-02-12):**
    -   **Correção:** Comandos SSH agora usam `sudo -n` (NOPASSWD) em vez de `echo password | sudo -S`.
-   **v2.1.0 (2026-02-12):**
    -   **Melhoria:** Adicionado `phpseclib3` para comunicação SSH em PHP puro, eliminando dependências externas.
-   **v2.0.0 (2026-02-11):**
    -   Versão inicial reescrita para integrar com `manage.sh` v10.0.

---

## 5. Ficheiros do Módulo

-   `nextcloudsaas.php`: Ficheiro principal com toda a lógica do ciclo de vida, botões e integração com o WHMCS.
-   `lib/SSHManager.php`: Classe robusta para gerir a comunicação SSH, com métodos que são wrappers diretos dos comandos do `manage.sh`.
-   `lib/Helper.php`: Funções utilitárias para formatação, validação e extração de configurações.
-   `lib/NextcloudAPI.php`: Cliente para a API OCS do Nextcloud, usado para testes de conectividade e alteração de passwords.
-   `templates/clientarea.tpl`: Template Smarty para a área de cliente, com um design moderno e informativo.
-   `hooks.php`: Referência para o ficheiro principal de hooks.
-   `includes/hooks/nextcloudsaas_hooks.php`: Hooks completos do módulo — ciclo de vida, personalização do carrinho, verificação DNS por cron, provisionamento automático, emails e notificações.
-   `whmcs.json`: Metadados do módulo.
-   `vendor/`: Contém a biblioteca `phpseclib3`.
