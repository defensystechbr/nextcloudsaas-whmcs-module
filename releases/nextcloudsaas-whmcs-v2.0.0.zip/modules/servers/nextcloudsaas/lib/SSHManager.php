<?php
/**
 * SSH Manager para comunicação com o servidor de destino
 *
 * Esta classe gere a conexão SSH ao servidor onde as instâncias
 * Nextcloud são hospedadas. Integra-se diretamente com o manage.sh
 * v10.0 existente no servidor, que é o script principal de gestão
 * de instâncias Nextcloud SaaS.
 *
 * Suporta autenticação por chave SSH ou por password, e utiliza
 * a extensão ssh2 do PHP quando disponível, com fallback para
 * o comando ssh do sistema.
 *
 * @package    NextcloudSaaS
 * @author     Manus AI / Defensys
 * @copyright  2026
 * @version    2.0.0
 */

namespace NextcloudSaaS;

class SSHManager
{
    /**
     * @var string Endereço IP ou hostname do servidor
     */
    private $host;

    /**
     * @var int Porta SSH
     */
    private $port;

    /**
     * @var string Utilizador SSH
     */
    private $username;

    /**
     * @var string Password SSH (se aplicável)
     */
    private $password;

    /**
     * @var string Caminho para a chave SSH privada (se aplicável)
     */
    private $privateKeyPath;

    /**
     * @var string Password da chave SSH (se aplicável)
     */
    private $keyPassphrase;

    /**
     * @var int Timeout da conexão em segundos
     */
    private $timeout;

    /**
     * @var string Caminho base das instâncias no servidor remoto
     */
    private $basePath;

    /**
     * @var string Caminho do manage.sh no servidor remoto
     */
    private $manageScript;

    /**
     * Construtor da classe SSHManager
     *
     * @param string $host           Endereço do servidor
     * @param string $username       Utilizador SSH
     * @param string $password       Password SSH (ou vazio para usar chave)
     * @param string $privateKeyPath Caminho para a chave privada SSH (ou vazio para usar password)
     * @param int    $port           Porta SSH (default: 22)
     * @param string $keyPassphrase  Passphrase da chave (default: vazio)
     * @param int    $timeout        Timeout em segundos (default: 300 para operações longas)
     * @param string $basePath       Caminho base no servidor (default: /opt/nextcloud-customers)
     */
    public function __construct(
        $host,
        $username,
        $password = '',
        $privateKeyPath = '',
        $port = 22,
        $keyPassphrase = '',
        $timeout = 300,
        $basePath = '/opt/nextcloud-customers'
    ) {
        $this->host = $host;
        $this->port = $port;
        $this->username = $username;
        $this->password = $password;
        $this->privateKeyPath = $privateKeyPath;
        $this->keyPassphrase = $keyPassphrase;
        $this->timeout = $timeout;
        $this->basePath = rtrim($basePath, '/');
        $this->manageScript = $this->basePath . '/manage.sh';
    }

    /**
     * Criar instância de SSHManager a partir dos parâmetros WHMCS
     *
     * @param array $params Parâmetros do módulo WHMCS
     * @return self
     */
    public static function fromWhmcsParams($params)
    {
        $server = Helper::getServerConfig($params);
        $product = Helper::getProductConfig($params);

        $host = !empty($server['ip']) ? $server['ip'] : $server['hostname'];

        return new self(
            $host,
            $server['username'],
            $server['password'],
            !empty($product['ssh_key_path']) ? $product['ssh_key_path'] : $server['accesshash'],
            $server['port'] > 0 ? $server['port'] : 22,
            '',
            300,
            '/opt/nextcloud-customers'
        );
    }

    /**
     * Executa um comando remoto via SSH
     *
     * @param string $command Comando a executar
     * @return array ['success' => bool, 'output' => string, 'error' => string, 'exit_code' => int]
     */
    public function executeCommand($command)
    {
        // Tentar extensão ssh2 primeiro
        if (function_exists('ssh2_connect')) {
            return $this->executeViaSsh2($command);
        }

        // Fallback: usar o comando ssh do sistema
        return $this->executeViaSystemSsh($command);
    }

    /**
     * Executa comando via extensão PHP ssh2
     *
     * @param string $command
     * @return array
     */
    private function executeViaSsh2($command)
    {
        $connection = @ssh2_connect($this->host, $this->port);
        if (!$connection) {
            return [
                'success'   => false,
                'output'    => '',
                'error'     => "Não foi possível conectar ao servidor {$this->host}:{$this->port}",
                'exit_code' => -1,
            ];
        }

        // Autenticar por password ou chave
        $authResult = false;
        if (!empty($this->password)) {
            $authResult = @ssh2_auth_password($connection, $this->username, $this->password);
        } elseif (!empty($this->privateKeyPath) && file_exists($this->privateKeyPath)) {
            $pubKeyPath = $this->privateKeyPath . '.pub';
            if (!file_exists($pubKeyPath)) {
                $pubKeyPath = null;
            }
            $authResult = @ssh2_auth_pubkey_file(
                $connection,
                $this->username,
                $pubKeyPath,
                $this->privateKeyPath,
                $this->keyPassphrase
            );
        }

        if (!$authResult) {
            return [
                'success'   => false,
                'output'    => '',
                'error'     => "Falha na autenticação SSH com o servidor {$this->host}",
                'exit_code' => -1,
            ];
        }

        // Encapsular o comando para capturar exit code
        $wrappedCommand = $command . '; echo "___EXIT_CODE___$?"';
        $stream = ssh2_exec($connection, $wrappedCommand);
        if (!$stream) {
            return [
                'success'   => false,
                'output'    => '',
                'error'     => "Falha ao executar o comando no servidor {$this->host}",
                'exit_code' => -1,
            ];
        }

        $errorStream = ssh2_fetch_stream($stream, SSH2_STREAM_STDERR);

        stream_set_blocking($stream, true);
        stream_set_blocking($errorStream, true);
        stream_set_timeout($stream, $this->timeout);

        $output = stream_get_contents($stream);
        $error = stream_get_contents($errorStream);

        fclose($stream);
        fclose($errorStream);

        // Extrair exit code do output
        $exitCode = -1;
        if (preg_match('/___EXIT_CODE___(\d+)/', $output, $matches)) {
            $exitCode = (int) $matches[1];
            $output = preg_replace('/___EXIT_CODE___\d+\s*$/', '', $output);
        }

        return [
            'success'   => ($exitCode === 0),
            'output'    => trim($output),
            'error'     => trim($error),
            'exit_code' => $exitCode,
        ];
    }

    /**
     * Executa comando via ssh do sistema (fallback)
     * Suporta autenticação por password (via sshpass) ou por chave
     *
     * @param string $command
     * @return array
     */
    private function executeViaSystemSsh($command)
    {
        if (!empty($this->password)) {
            // Usar sshpass para autenticação por password
            $sshCommand = sprintf(
                'sshpass -p %s ssh -o StrictHostKeyChecking=no -o ConnectTimeout=%d -p %d %s@%s %s 2>&1',
                escapeshellarg($this->password),
                min($this->timeout, 30),
                $this->port,
                escapeshellarg($this->username),
                escapeshellarg($this->host),
                escapeshellarg($command)
            );
        } elseif (!empty($this->privateKeyPath)) {
            $sshCommand = sprintf(
                'ssh -o StrictHostKeyChecking=no -o ConnectTimeout=%d -o BatchMode=yes -i %s -p %d %s@%s %s 2>&1',
                min($this->timeout, 30),
                escapeshellarg($this->privateKeyPath),
                $this->port,
                escapeshellarg($this->username),
                escapeshellarg($this->host),
                escapeshellarg($command)
            );
        } else {
            return [
                'success'   => false,
                'output'    => '',
                'error'     => 'Nenhum método de autenticação SSH configurado (password ou chave)',
                'exit_code' => -1,
            ];
        }

        $output = '';
        $exitCode = -1;
        exec($sshCommand, $outputLines, $exitCode);
        $output = implode("\n", $outputLines);

        return [
            'success'   => ($exitCode === 0),
            'output'    => trim($output),
            'error'     => ($exitCode !== 0) ? $output : '',
            'exit_code' => $exitCode,
        ];
    }

    // ================================================================
    // MÉTODOS DE INTEGRAÇÃO COM O MANAGE.SH
    // ================================================================

    /**
     * Executar o manage.sh com os argumentos fornecidos
     *
     * @param string $clientName  Nome do cliente
     * @param string $domain      Domínio (ou '_' para comandos que não precisam)
     * @param string $command     Comando do manage.sh (create, stop, start, etc.)
     * @return array Resultado da execução
     */
    public function runManage($clientName, $domain, $command)
    {
        $cmd = sprintf(
            'sudo bash %s %s %s %s',
            escapeshellarg($this->manageScript),
            escapeshellarg($clientName),
            escapeshellarg($domain),
            escapeshellarg($command)
        );

        Helper::log('SSHManager::runManage', [
            'client' => $clientName,
            'domain' => $domain,
            'command' => $command,
        ]);

        $result = $this->executeCommand($cmd);

        Helper::log('SSHManager::runManage result', $result);

        return $result;
    }

    /**
     * Criar uma nova instância Nextcloud via manage.sh
     *
     * @param string $clientName Nome do cliente (identificador único)
     * @param string $domain     Domínio principal do Nextcloud
     * @return array Resultado com credenciais
     */
    public function createInstance($clientName, $domain)
    {
        return $this->runManage($clientName, $domain, 'create');
    }

    /**
     * Parar (suspender) uma instância via manage.sh
     *
     * @param string $clientName Nome do cliente
     * @return array
     */
    public function stopInstance($clientName)
    {
        return $this->runManage($clientName, '_', 'stop');
    }

    /**
     * Iniciar (reativar) uma instância via manage.sh
     *
     * @param string $clientName Nome do cliente
     * @return array
     */
    public function startInstance($clientName)
    {
        return $this->runManage($clientName, '_', 'start');
    }

    /**
     * Remover (terminar) uma instância via manage.sh
     *
     * @param string $clientName Nome do cliente
     * @return array
     */
    public function removeInstance($clientName)
    {
        return $this->runManage($clientName, '_', 'remove');
    }

    /**
     * Obter o status de uma instância via manage.sh
     *
     * @param string $clientName Nome do cliente
     * @return array
     */
    public function statusInstance($clientName)
    {
        return $this->runManage($clientName, '_', 'status');
    }

    /**
     * Fazer backup de uma instância via manage.sh
     *
     * @param string $clientName Nome do cliente
     * @return array
     */
    public function backupInstance($clientName)
    {
        return $this->runManage($clientName, '_', 'backup');
    }

    /**
     * Atualizar uma instância via manage.sh
     *
     * @param string $clientName Nome do cliente
     * @return array
     */
    public function updateInstance($clientName)
    {
        return $this->runManage($clientName, '_', 'update');
    }

    /**
     * Obter as credenciais de uma instância via manage.sh
     *
     * @param string $clientName Nome do cliente
     * @return array
     */
    public function credentialsInstance($clientName)
    {
        return $this->runManage($clientName, '_', 'credentials');
    }

    /**
     * Listar todas as instâncias via manage.sh
     *
     * @return array
     */
    public function listInstances()
    {
        $cmd = sprintf('sudo bash %s list', escapeshellarg($this->manageScript));
        return $this->executeCommand($cmd);
    }

    /**
     * Ler o ficheiro .credentials de uma instância
     *
     * @param string $clientName Nome do cliente
     * @return array Credenciais parseadas
     */
    public function getCredentials($clientName)
    {
        $credPath = $this->basePath . '/' . $clientName . '/.credentials';
        $result = $this->executeCommand('cat ' . escapeshellarg($credPath));

        if ($result['success']) {
            $result['credentials'] = Helper::parseCredentials($result['output']);
        }

        return $result;
    }

    /**
     * Ler o ficheiro .env de uma instância
     *
     * @param string $clientName Nome do cliente
     * @return array Variáveis de ambiente parseadas
     */
    public function getEnv($clientName)
    {
        $envPath = $this->basePath . '/' . $clientName . '/.env';
        $result = $this->executeCommand('cat ' . escapeshellarg($envPath));

        if ($result['success']) {
            $env = [];
            foreach (explode("\n", $result['output']) as $line) {
                $line = trim($line);
                if (!empty($line) && strpos($line, '=') !== false) {
                    list($key, $value) = explode('=', $line, 2);
                    $env[trim($key)] = trim($value);
                }
            }
            $result['env'] = $env;
        }

        return $result;
    }

    // ================================================================
    // MÉTODOS DE GESTÃO DE UTILIZADORES VIA OCC
    // ================================================================

    /**
     * Executar um comando occ no container Nextcloud de uma instância
     *
     * @param string $clientName Nome do cliente
     * @param string $occCommand Comando occ (sem 'php occ')
     * @return array
     */
    public function runOcc($clientName, $occCommand)
    {
        $cmd = sprintf(
            'docker exec -u www-data %s php occ %s',
            escapeshellarg($clientName . '-app'),
            $occCommand
        );
        return $this->executeCommand($cmd);
    }

    /**
     * Criar um utilizador no Nextcloud
     *
     * @param string $clientName Nome da instância
     * @param string $ncUsername  Username do Nextcloud
     * @param string $ncPassword  Password do utilizador
     * @param string $displayName Nome de exibição
     * @param string $email       Email do utilizador
     * @param string $quota       Quota de armazenamento (ex: "5 GB")
     * @return array
     */
    public function createUser($clientName, $ncUsername, $ncPassword, $displayName = '', $email = '', $quota = '')
    {
        // Criar utilizador
        $cmd = sprintf(
            'export OC_PASS=%s && docker exec -u www-data -e OC_PASS %s php occ user:add --password-from-env %s',
            escapeshellarg($ncPassword),
            escapeshellarg($clientName . '-app'),
            escapeshellarg($ncUsername)
        );

        if (!empty($displayName)) {
            $cmd .= ' --display-name=' . escapeshellarg($displayName);
        }

        $result = $this->executeCommand($cmd);

        if (!$result['success']) {
            return $result;
        }

        // Definir email
        if (!empty($email)) {
            $this->runOcc($clientName, sprintf(
                'user:setting %s settings email %s',
                escapeshellarg($ncUsername),
                escapeshellarg($email)
            ));
        }

        // Definir quota
        if (!empty($quota)) {
            $this->runOcc($clientName, sprintf(
                'user:setting %s files quota %s',
                escapeshellarg($ncUsername),
                escapeshellarg(Helper::formatQuotaForNextcloud($quota))
            ));
        }

        return $result;
    }

    /**
     * Alterar a password de um utilizador no Nextcloud
     *
     * @param string $clientName  Nome da instância
     * @param string $ncUsername  Username
     * @param string $newPassword Nova password
     * @return array
     */
    public function changeUserPassword($clientName, $ncUsername, $newPassword)
    {
        $cmd = sprintf(
            'export OC_PASS=%s && docker exec -u www-data -e OC_PASS %s php occ user:resetpassword --password-from-env %s',
            escapeshellarg($newPassword),
            escapeshellarg($clientName . '-app'),
            escapeshellarg($ncUsername)
        );

        return $this->executeCommand($cmd);
    }

    /**
     * Desativar um utilizador no Nextcloud
     *
     * @param string $clientName Nome da instância
     * @param string $ncUsername Username
     * @return array
     */
    public function disableUser($clientName, $ncUsername)
    {
        return $this->runOcc($clientName, 'user:disable ' . escapeshellarg($ncUsername));
    }

    /**
     * Ativar um utilizador no Nextcloud
     *
     * @param string $clientName Nome da instância
     * @param string $ncUsername Username
     * @return array
     */
    public function enableUser($clientName, $ncUsername)
    {
        return $this->runOcc($clientName, 'user:enable ' . escapeshellarg($ncUsername));
    }

    /**
     * Alterar a quota de um utilizador
     *
     * @param string $clientName Nome da instância
     * @param string $ncUsername Username
     * @param string $quota      Nova quota (ex: "10 GB", "none")
     * @return array
     */
    public function setUserQuota($clientName, $ncUsername, $quota)
    {
        return $this->runOcc($clientName, sprintf(
            'user:setting %s files quota %s',
            escapeshellarg($ncUsername),
            escapeshellarg(Helper::formatQuotaForNextcloud($quota))
        ));
    }

    /**
     * Listar utilizadores de uma instância
     *
     * @param string $clientName Nome da instância
     * @return array
     */
    public function listUsers($clientName)
    {
        return $this->runOcc($clientName, 'user:list --output=json');
    }

    /**
     * Obter informações de um utilizador
     *
     * @param string $clientName Nome da instância
     * @param string $ncUsername Username
     * @return array
     */
    public function getUserInfo($clientName, $ncUsername)
    {
        return $this->runOcc($clientName, 'user:info ' . escapeshellarg($ncUsername) . ' --output=json');
    }

    // ================================================================
    // MÉTODOS DE DIAGNÓSTICO
    // ================================================================

    /**
     * Testar a conexão SSH com o servidor
     *
     * @return array Resultado do teste
     */
    public function testConnection()
    {
        $result = $this->executeCommand('echo "SSH_CONNECTION_OK" && hostname && uptime');

        if ($result['success'] && strpos($result['output'], 'SSH_CONNECTION_OK') !== false) {
            return [
                'success' => true,
                'message' => "Conexão SSH bem-sucedida com {$this->host}",
                'output'  => $result['output'],
            ];
        }

        return [
            'success' => false,
            'message' => "Falha na conexão SSH com {$this->host}: " . $result['error'],
        ];
    }

    /**
     * Verificar se o manage.sh existe no servidor
     *
     * @return array
     */
    public function verifyManageScript()
    {
        $result = $this->executeCommand(
            'test -f ' . escapeshellarg($this->manageScript) . ' && echo "EXISTS" || echo "MISSING"'
        );

        return [
            'exists'  => (strpos($result['output'], 'EXISTS') !== false),
            'path'    => $this->manageScript,
            'output'  => $result['output'],
        ];
    }

    /**
     * Verificar se o Docker está a correr no servidor
     *
     * @return array
     */
    public function verifyDocker()
    {
        $result = $this->executeCommand('docker info --format "{{.ServerVersion}}" 2>/dev/null');

        return [
            'running' => $result['success'],
            'version' => $result['success'] ? trim($result['output']) : 'N/A',
        ];
    }

    /**
     * Verificar se o Traefik está a correr
     *
     * @return array
     */
    public function verifyTraefik()
    {
        $result = $this->executeCommand(
            'docker ps --filter "name=traefik" --format "{{.Status}}" 2>/dev/null'
        );

        return [
            'running' => !empty($result['output']) && strpos($result['output'], 'Up') !== false,
            'status'  => trim($result['output']),
        ];
    }

    /**
     * Obter uso de disco de uma instância
     *
     * @param string $clientName Nome da instância
     * @return array
     */
    public function getDiskUsage($clientName)
    {
        $instancePath = $this->basePath . '/' . $clientName;
        $result = $this->executeCommand(
            'du -sh ' . escapeshellarg($instancePath) . ' 2>/dev/null'
        );

        $usage = 'N/A';
        if ($result['success'] && preg_match('/^([\d.]+[KMGT]?)/', $result['output'], $m)) {
            $usage = $m[1];
        }

        return [
            'success' => $result['success'],
            'usage'   => $usage,
            'raw'     => $result['output'],
        ];
    }
}
